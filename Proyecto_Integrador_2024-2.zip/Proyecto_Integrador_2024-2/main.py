from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/Sol_1', methods=['GET', 'POST'])
def calcular_sol_1():
    resultado = None
    if request.method == 'POST':
        try:
            num1 = int(request.form['num1'])
            num2 = int(request.form['num2'])
            resultado = num1 + num2
        except ValueError:
            resultado = "Por favor, ingresa números válidos."
    return render_template('Sol_1.html', resultado=resultado)

@app.route('/Sol_2', methods=['GET', 'POST'])
def sol_2():
    resultado = None
    if request.method == 'POST':
        try:
            numero = int(request.form['numero'])
            if numero % 2 == 0:
                resultado = f"El número {numero} es par."
            else:
                resultado = f"El número {numero} es impar."
        except ValueError:
            resultado = "Por favor, ingresa un número válido."
    return render_template('Sol_2.html', resultado=resultado)


@app.route('/Sol_3', methods=['GET', 'POST'])
def sol_3():
    resultado = None
    if request.method == 'POST':
        try:
            lista = request.form['lista']
            numeros = list(map(int, lista.split(',')))
            resultado = sorted(numeros)
        except ValueError:
            resultado = "Por favor, ingresa una lista válida de números separados por comas."
    return render_template('Sol_3.html', resultado=resultado)

@app.route('/Sol_4', methods=['GET', 'POST'])
def sol_4():
    resultado = None
    if request.method == 'POST':
        try:
            numero = float(request.form['numero']) 
            if numero > 0:
                resultado = f"El número {numero} es positivo."
            elif numero < 0:
                resultado = f"El número {numero} es negativo."
            else:
                resultado = "El número ingresado es cero."
        except ValueError:
            resultado = "Por favor, ingresa un número válido."
    return render_template('Sol_4.html', resultado=resultado)

@app.route('/Sol_5', methods=['GET', 'POST'])
def sol_5():
    resultado = None
    if request.method == 'POST':
        try:
            numero1 = int(request.form['numero1'])
            numero2 = int(request.form['numero2'])
            if numero2 == 0:
                resultado = "No se puede dividir entre cero."
            elif numero1 % numero2 == 0:
                resultado = f"{numero1} es múltiplo de {numero2}."
            else:
                resultado = f"{numero1} no es múltiplo de {numero2}."
        except ValueError:
            resultado = "Por favor, ingresa números válidos."
    return render_template('Sol_5.html', resultado=resultado)

@app.route('/Sol_6', methods=['GET', 'POST'])
def sol_6():
    hipotenusa = None
    if request.method == 'POST':
        try:
            numero1 = float(request.form['cateto1'])
            numero2 = float(request.form['cateto2'])
            hipo = (numero1**2+numero2**2)**0.5
            hipotenusa=round(hipo, 2)
        except ValueError:
            hipotenusa = "Por favor, ingresa números válidos."
    return render_template('Sol_6.html', resultado=hipotenusa)


if __name__ == '__main__':
    app.run(debug=True)
